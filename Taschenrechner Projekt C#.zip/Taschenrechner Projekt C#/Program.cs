﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Einfacher Taschenrechner");
        Console.WriteLine("Gib eine Rechnung ein, z.B. 2 + 2");
        Console.WriteLine("Mit 'exit' beenden.");

        while (true)
        {
            Console.Write("> ");
            string eingabe = Console.ReadLine();

            if (eingabe == "exit")
            {
                break;
            }

            string[] teile = eingabe.Split(' ');

            if (teile.Length != 3)
            {
                Console.WriteLine("Bitte so eingeben: Zahl Operator Zahl");
                Console.WriteLine("Beispiel: 2 + 2");
                continue;
            }

            double zahl1 = Convert.ToDouble(teile[0]);
            string op = teile[1];
            double zahl2 = Convert.ToDouble(teile[2]);

            double ergebnis = 0;

            switch (op)
            {
                case "+":
                    ergebnis = zahl1 + zahl2;
                    break;

                case "-":
                    ergebnis = zahl1 - zahl2;
                    break;

                case "*":
                    ergebnis = zahl1 * zahl2;
                    break;

                case "/":
                    if (zahl2 == 0)
                    {
                        Console.WriteLine("Division durch 0 ist nicht erlaubt.");
                        continue;
                    }

                    ergebnis = zahl1 / zahl2;
                    break;

                default:
                    Console.WriteLine("Ungültiger Operator.");
                    continue;
            }

            Console.WriteLine("= " + ergebnis);
        }

        Console.WriteLine("Auf Wiedersehen!");
    }
}